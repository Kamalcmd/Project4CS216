#pragma once
#include <list>
#include <memory>
#include <istream>

#include "IEquation.h"

class EquationFactory
{

public:
    #pragma region Json strings
    static const std::string EQUATIONS_TAG;
    #pragma endregion

    ///
    /// Given an input stream convert the data it points to into a collection of IEquation 
    /// unique pointers.
    /// <parm input>An istream point to the json data to be converted into IEquations </parm>
    std::list<std::unique_ptr<IEquation>> make();

    EquationFactory() = default;
};

