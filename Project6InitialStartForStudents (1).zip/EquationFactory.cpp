
#include <fstream>
#include <iostream>

#include "json_3_7_2.hpp" 

#include "EquationFactory.h"
#include "AddEquation.h"

using json = nlohmann::json;

const std::string EquationFactory::EQUATIONS_TAG = "equations";
std::list<std::unique_ptr<IEquation>> EquationFactory::make()
{
    const std::string  fileName = "simpleData.json";
    json parser;
    std::list<std::unique_ptr<IEquation>> equations;

    // Open file for reading.
    // check if it is open.
    std::ifstream  inputStream(fileName, std::ifstream::in);
    if (inputStream.is_open() == false)
    {
        std::cout << "Error: Unable to open file:" << fileName << std::endl;
        exit(1);
    }
    
    // set up the json parser w/ an input stream.
    inputStream >> parser;


    // 0) pull the array of json object from the parser
    auto jsonEquations = parser[EQUATIONS_TAG];

    // 1) go throught the array of json objects
    // 2) find out the type of the current oject
    // 3) make the object of that type and set it to the values in the current jason object
    // 4) put the object into the list
    for (auto eq : jsonEquations)
    {
        auto eqOp = eq[EquationBase::OP_TAG].get<std::string>();
        // 2)
        if (eqOp == EquationBase::ADDITION_TAG)
        {
            // 3)
            auto tmp = std::make_unique<AddEquation>();
            tmp->setOp(Operand::Addition);
            tmp->setLeftNumber(eq[EquationBase::LEFT_NUMBER_TAG].get<float>());
            tmp->setRightNumber(eq[EquationBase::RIGHT_NUMBER_TAG].get<float>());

            // 4)
            equations.push_back(std::move(tmp));
        }
    }
    return equations;
}
