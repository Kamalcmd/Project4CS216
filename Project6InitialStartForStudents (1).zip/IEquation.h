#pragma once
#include <string>
#include "ICommand.h"

enum class Operand
{
    Addition
};

class IEquation:public ICommand
{
public:
    virtual Operand getOperand() const = 0;
    virtual float getLeftNumber() const = 0;
    virtual float getRightNumber() const = 0;
    virtual float getAnswer() const = 0;

    ///
    /// Method to allow dynamic overloading of this method which is used in operator overloading.
    virtual void output(std::ostream& os) = 0;

    /// Note: IEquation.output is called to do the work, this method is just a wrapper.
    ///       IEquation.output uses dynamic binding.
    friend std::ostream& operator<<(std::ostream& os, IEquation& eq)
    {
        eq.output(os);
        return os;
    }

    virtual ~IEquation() {};
};
