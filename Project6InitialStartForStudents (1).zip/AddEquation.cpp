#include "AddEquation.h"

void AddEquation::execute()
{
    float answer = getLeftNumber() + getRightNumber();
    setAnswer(answer);
}

void AddEquation::output(std::ostream& os)
{
   os << getLeftNumber() << " + "
      << getRightNumber() << " = " << getAnswer() << std::endl;
}
