// program6.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <fstream>
#include <sstream>
#include "EquationFactory.h"

int main()
{

    {
        EquationFactory   eqFactory;
        auto equations = eqFactory.make();
        for (auto& eq : equations)
        {
            eq->execute();
            // This is a little tricky we can not just dereference the pointer to point to 
            // IEquation as set that to a var, as IEquation is an ABC and you can not have a variable of type 
            // IEquation, you can only have a pointer or reference to it. 
            auto& tmp = *(eq.get());
            std::cout << tmp;
        }
    }
}
