#pragma once
#include "IEquation.h"
#include <string>

///
/// Implement the ABC IEquation but not ICommand. 
///
class EquationFactory;
class EquationBase: public IEquation
{
private:
    Operand     _op;
    float       _leftNum = 0.0;
    float       _rightNum = 0.0;
    float       _answer = 0.0;

public:
    #pragma region Json strings
    static const std::string OP_TAG;
    static const std::string LEFT_NUMBER_TAG;
    static const std::string RIGHT_NUMBER_TAG;

    static const std::string ADDITION_TAG;
    #pragma endregion

    #pragma region IEquation interface
    // The virtual keyword is so derived classes can override if desired.
    Operand getOperand() const override;
    float getLeftNumber() const override;
    float getRightNumber() const override;
    float getAnswer() const override;
    // This is an ABC there is no need to ever have an object of this type
    // and implementation of this method can not be done in a generic way.
    // The following IEquation method is not implemented.
    // virtual void output(std::ostream& outStream) = 0;
    #pragma endregion

    friend EquationFactory;
    virtual ~EquationBase() {}
protected:
    void setAnswer(float answer);

private:
    void setOp(Operand op);
    void setLeftNumber(float lnum);
    void setRightNumber(float rnum);

    /// <summary> Case-insensitive string comparison in C++ </summary>
    bool isEqual(const std::string& lhs, const std::string& rhs);
};
