#include "EquationBase.h"
#include <iostream>

const std::string EquationBase:: OP_TAG = "operand";
const std::string EquationBase::LEFT_NUMBER_TAG = "leftNumber";
const std::string EquationBase::RIGHT_NUMBER_TAG = "rightNumber";

const std::string EquationBase::ADDITION_TAG = "+";

Operand EquationBase::getOperand() const
{
    return _op;
}
float EquationBase::getLeftNumber() const
{
    return _leftNum;
}

float EquationBase::getRightNumber() const
{
    return _rightNum;
}

float EquationBase::getAnswer() const
{
    return _answer;
}


void EquationBase::setAnswer(float answer)
{
    _answer = answer;
}

void EquationBase::setOp(Operand op)
{
    _op = op;
}

void EquationBase::setLeftNumber(float leftNum)
{
    _leftNum = leftNum;
}

void EquationBase::setRightNumber(float rightNum)
{
    _rightNum = rightNum;
}

bool EquationBase::isEqual(const std::string& lhs, const std::string& rhs) 
{
    return std::equal(lhs.begin(), lhs.end(),
                      rhs.begin(), rhs.end(),
                      [](char lhsa, char rhsb) 
                      {
                          return tolower(lhsa) == tolower(rhsb);
                      });
}
